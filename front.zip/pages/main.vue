<template>
  <v-container>
    
    <bottom-nav />
  </v-container>
</template>

<script>
import BottomNav from '../components/BottomNav.vue';
  export default {
    components: {
        BottomNav,
    }
  }
</script>